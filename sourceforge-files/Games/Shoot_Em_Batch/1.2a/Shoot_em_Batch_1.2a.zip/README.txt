 Shoot 'em Batch: An great example of batch capabilities using Seta:Dsp, Seta:GPU And Chombie[-_-]
 Copyright (C) 2012,2013  Honguito98, Jan Ringos

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 This is an ported game, i.e Shoot 'em is developed by Jan Ringos
 The point is only for know at certain limits of batch files
 using some executables for commandline and NOT for theft
 CREDITS.

 This ported game, game code, techniques, including Seta:DSP,
 Seta:GPU, Chombie[-_-], Fn.dll (Seta:Core), reverse engineer are
 developed by Honguito98.
 
 None of the abovementioned are responsible for damage or loss of
 information.