# EncTool for Windows batch files

## What it is?
Development tool for text protection within batch files.
