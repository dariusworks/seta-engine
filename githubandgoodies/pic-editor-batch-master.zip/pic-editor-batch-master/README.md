# Pic Editor
Yet another simple sprite/map editor

## What is this?
A development tool for create sprites, maps and pictures in ANSI escapes sequences format.

## What is the difference between Map Editor and this
Pic Editor is even simpler, and uses ANSI escape sequences, while Map Editor can import/export this format, Pic Editor works natively.
Just do not need to worry about software incompatibilities!

## Includes some examples?
Of course! It includes some pic files used in the batch game 'viewpoint'.
