# Seta Engine for Batch games
Engines for Batch Script-based games.


Versions
----
Exists differents versions of this engine for a specific need.
* A: simple engine, monochrome only
* B: simple engine, multicolored support
