# [Batch game] viewpoint
A batchfile-based game based from a 90's video game, of same name.

## About
This game was programed by me, it was writen in 2012-2013, at my 13-years old, in my free time.
Also, it demostrates my unreleased game engine capabilities, using some external utilities, like ANSICON, BG.exe, etc.
The music and sfx sources was recorded from the original game, thus i am not the composer of this.

## How to play?

![howto](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_howto.png)

## How to download?
Do click on "Clone/Download" button, then click "Download ZIP"

## Some screenshots
![img1](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_init.png)
![img2](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_lv1.png)
![img3](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_lv2.png)
![img4](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_lv3.png)
![img5](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_lv4.png)
![img6](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_lv5.png)
![img7](http://i1060.photobucket.com/albums/t452/honguito98/viewpoint_lv6.png)
