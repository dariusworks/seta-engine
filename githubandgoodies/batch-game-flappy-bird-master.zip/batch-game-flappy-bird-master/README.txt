 Flappy Bird Coded In Batch: Another example using Seta:DSP, Seta:GPU
 Copyright (C) 2013,2014 Honguito98

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 This is an adapted game, i.e Flappy Bird is originally created by Dong Nguyen.
 The only purpose is to evaluate performance of batch files
 using some executables for commandline.

 This adapted game, game code, techniques, including Seta:DSP,
 Seta:GPU, Fn.dll (Seta:Core), are developed by Honguito98.
 
 None of the above mentioned are responsible for damage or loss of
 information.